<section class="find_state" style="background: url(assets/images/find_state.jpg);">
    <div id="vbg12" data-vbg-loop="true" data-vbg="https://youtu.be/ec_fXMrD7Ow?si=m9LJu9X3lzTP5Erz">
    </div>
    <div class="container">
        <div class="row wow fadeInUp" data-wow-duration="1.5s">
            <div class="col-xl-12">
                <div class="find_state_text">
                    <h2>Resumé de nos rénovations</h2>
                    <a href='property_details.html'><i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
