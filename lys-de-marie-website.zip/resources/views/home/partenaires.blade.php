<section class="partner_area pt_60 pb_60">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-xl-12">
                <div class="marquee_animi">
                    <ul class="single_partner">
                        <li><a href='agencies_details.html'><img src="assets/images/partner_1.png" alt="img"
                                    class="img-fluid w-100"></a>
                        </li>
                        <li><a href='agencies_details.html'><img src="assets/images/partner_10.png" alt="img"
                                    class="img-fluid w-100"></a>
                        </li>
                        <li><a href='agencies_details.html'><img src="assets/images/partner_3.png" alt="img"
                                    class="img-fluid w-100"></a>
                        </li>
                        <li><a href='agencies_details.html'><img src="assets/images/partner_4.png" alt="img"
                                    class="img-fluid w-100"></a>
                        </li>
                        <li><a href='agencies_details.html'><img src="assets/images/partner_5.png" alt="img"
                                    class="img-fluid w-100"></a>
                        </li>
                        <li><a href='agencies_details.html'><img src="assets/images/partner_6.png" alt="img"
                                    class="img-fluid w-100"></a>
                        </li>
                        <li><a href='agencies_details.html'><img src="assets/images/partner_7.png" alt="img"
                                    class="img-fluid w-100"></a>
                        </li>
                        <li><a href='agencies_details.html'><img src="assets/images/partner_8.png" alt="img"
                                    class="img-fluid w-100"></a>
                        </li>
                        <li><a href='agencies_details.html'><img src="assets/images/partner_9.png" alt="img"
                                    class="img-fluid w-100"></a>
                        </li>
                        <li><a href='agencies_details.html'><img src="assets/images/partner_10.png" alt="img"
                                    class="img-fluid w-100"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
