<nav class="navbar navbar-expand-lg main_menu">
    <div class="container container_large">
        <a class='navbar-brand' href='<?php echo e(route('home')); ?>'>
            <img src="<?php echo e(asset('assets/images/logos/logo-lys.jpg')); ?>" class="logonav" width="50px" alt="FaxEstate"
                class="img-fluid">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fas fa-bars bar_icon"></i>
            <i class="far fa-times close_icon"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav m-auto">
                <li class="nav-item">
                    <a class='nav-link <?php echo e($menu == 'home' ? 'active' : ''); ?>' href='<?php echo e(route('home')); ?>'>Accueil</a>
                </li>
                <li class="nav-item">
                    <a class='nav-link <?php echo e($menu == 'about' ? 'active' : ''); ?>' href='<?php echo e(route('about')); ?>'>A propos</a>
                </li>
                <li class="nav-item">
                    <a class='nav-link <?php echo e($menu == 'propertie' ? 'active' : ''); ?>'
                        href='<?php echo e(route('propertie')); ?>'>Propriétés</a>
                </li>
            </ul>
            <ul class="menu_right d-flex align-items-center">

                <li class="manu_btn">
                    <a href="<?php echo e(route('contact')); ?>" class='common_btn' href=''>Contactez-nous</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /Users/mac/development/lys-marie-website/resources/views/layouts/partials/nav.blade.php ENDPATH**/ ?>