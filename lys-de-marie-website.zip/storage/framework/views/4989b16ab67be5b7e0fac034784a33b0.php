<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densityDpi=device-dpi" />
    <title>LES LYS DE MARIE - <?php echo e($title); ?> </title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/logos/logo-lys.jpg')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animated_barfiller.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/summernote.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/scroll_button.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/utilities.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.simple-bar-graph.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
</head>
<?php /**PATH /Users/mac/development/lys-marie-website/resources/views/layouts/partials/head.blade.php ENDPATH**/ ?>