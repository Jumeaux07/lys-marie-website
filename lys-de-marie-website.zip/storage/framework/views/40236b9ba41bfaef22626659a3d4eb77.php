<section class="banner_area" style="background: url(assets/images/banner_bg.jpg);">
    
    <div class="container container_large">
        <div class="row wow fadeInUp" data-wow-duration="1.5s">
            <div class="col-xl-11 col-xxl-9">
                <div class="banner_contant">
                    <div class="banner_text">
                        <h1>Construire des maisons où l'on se sent comme chez soi - avec nous.</h1>

                    </div>
                    <div class="banner_search">
                        <ul class="nav nav-pills" id="pills-tab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-home" type="button" role="tab"
                                    aria-controls="pills-home" aria-selected="true">En vente</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-profile" type="button" role="tab"
                                    aria-controls="pills-profile" aria-selected="false">En location</button>
                            </li>
                        </ul>

                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                                aria-labelledby="pills-home-tab" tabindex="0">
                                <form action="#">
                                    <ul class="d-flex flex-wrap">
                                        <li>
                                            <label>Villes</label>
                                            <select class="select_2" name="state">
                                                <option value="">Selectionner une ville</option>
                                                <option value="">Abidjan</option>
                                                <option value="">Bassam</option>
                                            </select>
                                        </li>
                                        <li>
                                            <label>Type</label>
                                            <select class="select_2" name="state">
                                                <option value="">Selectionner le type</option>
                                                <option value="">Appartment</option>
                                                <option value="">Villa</option>
                                            </select>
                                        </li>
                                        
                                        <li>
                                            <input type="text" placeholder="Entrer un mot clé...">
                                        </li>
                                    </ul>
                                    <button class="common_btn banner_input_btn" type="submit">Rechercher</button>
                                    
                                    
                                </form>
                            </div>
                            <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                aria-labelledby="pills-profile-tab" tabindex="0">
                                <form action="#">
                                    <ul class="d-flex flex-wrap">
                                        <li>
                                            <label>Villes</label>
                                            <select class="select_2" name="state">
                                                <option value="">Selectionner le ville</option>
                                                <option value="">Bassam</option>
                                            </select>
                                        </li>
                                        <li>
                                            <label>Type</label>
                                            <select class="select_2" name="state">
                                                <option value="">Selectionner le type</option>
                                                <option value="">Appartment</option>
                                                <option value="">Villa</option>
                                            </select>
                                        </li>
                                        
                                        <li>
                                            <input type="text" placeholder="Entrer un mot clé...">
                                        </li>
                                    </ul>
                                    <button class="common_btn banner_input_btn" type="submit">Rechercher</button>
                                    
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /Users/mac/development/lys-marie-website/resources/views/home/banner.blade.php ENDPATH**/ ?>