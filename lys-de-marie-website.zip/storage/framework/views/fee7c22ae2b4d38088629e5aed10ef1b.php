<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.bredcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="property_details pt_120 xs_pt_100 pb_105 xs_pb_85">
        <div class="container">
            <div class="row wow fadeInUp" data-wow-duration="1.5s">
                <div class=" col-xl-12">
                    <div class="property_details_slider">
                        <div class="row slider-for2">
                            <div class="col-12">
                                <div class="property_details_large_img">
                                    <img src="assets/images/property_details_img_1.jpg" alt="img-fluid w-100">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="property_details_large_img">
                                    <img src="assets/images/property_details_img_2.jpg" alt="img-fluid w-100">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="property_details_large_img">
                                    <img src="assets/images/property_details_img_3.jpg" alt="img-fluid w-100">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="property_details_large_img">
                                    <img src="assets/images/property_details_img_4.jpg" alt="img-fluid w-100">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="property_details_large_img">
                                    <img src="assets/images/property_details_img_3.jpg" alt="img-fluid w-100">
                                </div>
                            </div>
                        </div>

                        <div class="row slider-nav2">
                            <div class="col-xl-4">
                                <div class="property_details_small_img">
                                    <img src="assets/images/property_details_img_1.jpg" alt="img-fluid w-100">
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div class="property_details_small_img">
                                    <img src="assets/images/property_details_img_2.jpg" alt="img-fluid w-100">
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div class="property_details_small_img">
                                    <img src="assets/images/property_details_img_3.jpg" alt="img-fluid w-100">
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div class="property_details_small_img">
                                    <img src="assets/images/property_details_img_4.jpg" alt="img-fluid w-100">
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div class="property_details_small_img">
                                    <img src="assets/images/property_details_img_3.jpg" alt="img-fluid w-100">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt_50">
                <div class="col-lg-8">
                    <div class="single_property_details mt_25 wow fadeInUp" data-wow-duration="1.5s">
                        <h4>Description</h4>
                        <p class=" property_dtls_decription">Découvrez cette charmante maison située dans un environnement
                            paisible, idéale pour une famille à la recherche de confort et de fonctionnalité.

                            Édifiée sur un terrain bien aménagé, cette propriété offre de beaux volumes avec un salon
                            lumineux, une cuisine moderne entièrement équipée, plusieurs chambres spacieuses, des salles de
                            bain élégantes, ainsi qu’un espace extérieur agréable parfait pour vos moments de détente ou de
                            convivialité.

                            Bénéficiant d'une construction solide et de finitions soignées, cette maison allie confort
                            moderne et cadre de vie serein. Elle se trouve à proximité des écoles, commerces et axes
                            routiers, tout en offrant un havre de paix à ses occupants.

                            Un bien rare à visiter sans tarder.</p>

                    </div>
                    <div class="single_property_details mt_25 wow fadeInUp" data-wow-duration="1.5s">
                        <h4>Details</h4>
                        <ul class=" property_apartment_details d-flex flex-wrap mt_10">
                            <li>
                                <p>ID:<span>F257481</span></p>
                            </li>
                            <li>
                                <p>Chambres:<span>5</span></p>
                            </li>
                            <li>
                                <p>Status:<span>En vente</span></p>
                            </li>
                            <li>
                                <p>Garages:<span>2</span></p>
                            </li>
                            <li>
                                <p>Douches:<span>2</span></p>
                            </li>
                        </ul>
                        
                    </div>
                    <div class="single_property_details mt_25 wow fadeInUp" data-wow-duration="1.5s">
                        <h4> Plans</h4>
                        <div class=" apertment_layout">
                            <img src="assets/images/layout.jpg" alt="img" class="img-fluid w-100">
                        </div>
                    </div>
                    
                    <div class="single_property_details mt_25 wow fadeInUp" data-wow-duration="1.5s">
                        <h4>Video</h4>
                        <div class=" apertment_video">
                            <iframe src="https://www.youtube.com/embed/ec_fXMrD7Ow?si=E-z18uXLa_wbsPXg"
                                title="YouTube video player"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="sticky_sidebar">
                        <div class="property_details_sidebar">
                            <h4>Planifier une visite</h4>
                            <form action="#" class="schedule_form">
                                <div class="row">
                                    <div class="col-lg-12 col-md-6">
                                        <div class="schedule_input">
                                            <input type="text" placeholder="Date">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6">
                                        <div class="schedule_input">
                                            <input type="text" placeholder="Heure">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6">
                                        <div class="schedule_input">
                                            <input type="text" placeholder="Nom">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-6">
                                        <div class="schedule_input">
                                            <input type="text" placeholder="Téléphonne">
                                        </div>
                                    </div>
                                    <div class="col-xl-12">
                                        <div class="schedule_input">
                                            <input type="email" placeholder="Adresse Email">
                                        </div>
                                    </div>
                                    <div class="col-xl-12">
                                        <div class="schedule_input">
                                            <textarea rows="5" placeholder="Message"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-xl-12">
                                        <div class="schedule_input">
                                            <a href="#" class="common_btn">Soumettre</a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/development/lys-marie-website/resources/views/propertie/show.blade.php ENDPATH**/ ?>